#define LBRACE 1
#define RBRACE 2
#define LOOP 3
#define PRINT 4
#define ASSIGN 5
#define FUNCTION 6
#define NUMBER 7
#define IDENTIFIER 8
#define DOLLAR 9
#define P 10
#define T 11
#define S 12
#define R 13
#define C 14
#define ERROR 100
  


