


How to run:

1. Unzip the file

2. Goto folder in terminal

3. Compile command$: make p1
		(compiles the cfp.exe with FP.lex)

4. Run command$: ./cfp.exe <table file> < <sfp file>
		(This will print the output on the console, you can try other input files as well, sample2.fp and sample3.fp)

5. Run command$: ./cfp.exe < sample1.fp > sample1.output
		(This will print the output to the sample1.output file)

6. Clean command$: make clean
		







Thank You 
Ronak Shah(rxs144130)
